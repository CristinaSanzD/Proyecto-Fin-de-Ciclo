import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-terminos',
  templateUrl: './terminos.component.html'
})
export class TerminosComponent implements OnInit {

  constructor() {
    window.scrollTo(500, 0);
  }

  ngOnInit(): void {
  }

}
