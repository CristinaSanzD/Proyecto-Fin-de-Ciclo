import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html'
})
export class ContactoComponent implements OnInit {

  constructor() {
    window.scrollTo(500, 0);
   }

  ngOnInit(): void {
  }

}
