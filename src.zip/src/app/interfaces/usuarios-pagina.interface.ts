export interface User {
  apellidos?: string;
  email?: string;
  nombre?: string;
  password?: string;
  rol?: string;
  usuario?: string;
}
